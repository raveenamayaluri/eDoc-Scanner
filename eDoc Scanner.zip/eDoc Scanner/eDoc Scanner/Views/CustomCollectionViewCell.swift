//
//  CustomCollectionViewCell.swift
//  Scan-app
//
//  Created by Viswanath Reddy on 21.07.2019.
//  Copyright © 2019 Viswanath Reddy. All rights reserved.

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var documentType: UILabel!
    
}
